package org.tripatj.E2EAutomation.service;


import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.reflect.TypeToken;
import cucumber.api.Scenario;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;
import org.springframework.web.util.UriComponentsBuilder;
import org.tripatj.E2EAutomation.model.L3ProgressUpdate;
import org.tripatj.E2EAutomation.model.TestRequest;
import org.tripatj.E2EAutomation.model.TestResult;
import org.tripatj.E2EAutomation.model.cucumber.Element;
import org.tripatj.E2EAutomation.model.cucumber.Feature;
import org.tripatj.E2EAutomation.testCentral.model.L3TestRequest;
import org.tripatj.E2EAutomation.testCentral.repository.L3ResultRepository;
import org.tripatj.E2EAutomation.testCentral.service.L3ResultService;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.InetAddress;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

@Component
public class TestReportService {
    private static final Logger logger= LoggerFactory.getLogger(TestReportService.class);
    private static final String TEST_CENTRAL_END_POINT= "/l3Result/saveL3Result/";

    @Value("${build.no}")
    private String sysTestBuildNumber;

    @Value("${testcentral.ws.base.url}}")
     private String testCentralURL;

    @Autowired
    private L3ResultRepository testResultRepository;

    @Autowired
    private L3ResultService l3ResultService;

    @Autowired
    private RestTemplateBuilder restTemplateBuilder;

    public void addEmptyRecordInTestCentral(long startTime,String envName,String buildNo,String testRunBuildNo, String reportType){
        TestResult testResult= new TestResult();
        try{
          testResult=createTestResult(startTime,0,envName,buildNo,testRunBuildNo,null,reportType);
            JsonElement jsonElement= new Gson().fromJson(testResult.getResultObjects(),JsonElement.class);
            JsonObject jsonObject=jsonElement.getAsJsonObject();
          /*  if(! sendResultsToTestCentral(jsonObject)){
                testResult.setFailureMessage("Explain while saving results to testcentral ");
            }*/

            logger.info("Cucumber Report updateed to testcentral");
        }
        catch(Exception e){
            logger.error("Exception while savings results to testcentral", e);
            testResult.setFailureMessage("System-test : Exception while creating test results - unable to send them to testcentral.error"+e.getMessage());
        }
    }

    public TestResult saveTestResultToTestCentral(long startTime,String envName, String buildNo, String testRunBuildNo,String reportType){
        long endTime = System.currentTimeMillis();
        String absPath= Paths.get("").toAbsolutePath().toString();
        String jsonFilePath= absPath+ File.separator+"target"+File.separator+"cucumber.json";
        Path path= Paths.get(jsonFilePath);
        TestResult testResult= new TestResult();

       if(path.toFile().exists()){
           try{
             testResult= createTestResult(startTime,endTime,envName,buildNo,testRunBuildNo, jsonFilePath, reportType);
             JsonElement jsonElement= new Gson().fromJson(testResult.getResultObjects(),JsonElement.class);
             JsonObject jsonObject= jsonElement.getAsJsonObject();
            /* if( !sendResultsToTestCentral(jsonObject)){
               testResult.setFailureMessage("Explain while saving results to testcentral");
             }*/
             logger.info("Cucumber Report updated to testCentral");
           }
           catch(Exception e){
               logger.error("Exception while savings results to testcentral", e);
               testResult.setFailureMessage("system-tes : Exception while creating test-results - unable to send them to testcentral. Error=" + e.getMessage());

           }
       }
       else {
           logger.warn("cucumber.json file does not exist : {} ", jsonFilePath);
       }
        return testResult;
    }

    protected boolean sendResultsToTestCentral(JsonObject jsonObject){
        boolean status= Boolean.FALSE;
        /*logger.info("Calling testCentral api to update cucumber report");
        try{
            UriComponentsBuilder builder= UriComponentsBuilder.fromHttpUrl(this.testCentralURL+TEST_CENTRAL_END_POINT);
            HttpHeaders headers= new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity= new HttpEntity<>(jsonObject.toString(),headers);
            ResponseEntity<Void> responseEntity = this.restTemplateBuilder.build().postForEntity(builder.build().toUri(),entity,Void.class);
            if((null!= responseEntity) && StringUtils.equals(responseEntity.getStatusCode().toString(), HttpStatus.CREATED.toString())){
                status=Boolean.TRUE;
                return status;
            }
        }
        catch(Exception e){
            logger.error("Exception while updating results to testCentral {} :", e);
            status= Boolean.FALSE;
        }*/
        status=Boolean.TRUE;
        return status;
    }

    protected TestResult createTestResult(long starTime,long endTime, String envName,String buildNumber,String testRunbuildNumber,String jsonPath, String reportType){
        TestResult result= new TestResult();
       if( !StringUtils.isEmpty(jsonPath)){
           List<Feature> features=deserializeCucumberJsonFile(jsonPath);
           features=(null!=features) ? features : Collections.emptyList();
           List<Element> scenarios= features.stream().filter(Objects::nonNull).map(Feature::getElements).filter(Objects::nonNull).flatMap(Collection::stream)
                   .filter(Objects::nonNull).filter(e ->StringUtils.equals("scenario",e.getType()) || StringUtils.equals("background",e.getType())).collect(Collectors.toList());
           for(Element element:scenarios){
                if(didScenarioPass(element)){
                    result.incrementPassCount();
                }else{
                    result.incrementFailedCount();
                }
           }
       }
       else{
           result.setPassCount(0);
           result.setPassCount(0);
       }
      /* String jsonContent=getFinalJsonContent(jsonPath,envName,buildNumber,testRunbuildNumber,result,starTime,endTime, L3ProgressUpdate.getL3TestGroupId().getTestGroupId(),reportType,false);
       result.setResultObjects(jsonContent);*/
        /*temprory addded until Saparate Test Central Project get setup*/
        L3TestRequest req= temprorySetTestCentralL3TestRequestObject(jsonPath,envName,buildNumber,testRunbuildNumber,result,starTime,endTime, L3ProgressUpdate.getL3TestGroupId().getTestGroupId(),reportType,false);
        l3ResultService.saveResults(req);
        /*temprory addded until Saparate Test Central Project get setup*/
        return result;
    }

    public L3TestRequest temprorySetTestCentralL3TestRequestObject(String jsonPath, String env, String buildNbr,String testRunBuildNumber,
                                                          TestResult testCounts,long startTime, long endTime,String testGroupId,String reportType, boolean finalize){
        boolean status= Boolean.FALSE;
        L3TestRequest l3TestRequest= new L3TestRequest();
        try{

                l3TestRequest.setTestgroupid(testGroupId);
                l3TestRequest.setEnvname(env);
                l3TestRequest.setBuildnbr(buildNbr);
                l3TestRequest.setSystestbuildnbr(sysTestBuildNumber);
                l3TestRequest.setTestrunbuildnbbr(testRunBuildNumber);
                l3TestRequest.setMachinename(getHostName());
                l3TestRequest.setTotaltestcnt(testCounts.getTotalTests());
                l3TestRequest.setTotalsuccesscnt(testCounts.getPassCount());
                l3TestRequest.setTotalfailcnt(testCounts.getFailCount());
                l3TestRequest.setStarttime(startTime);
                l3TestRequest.setEndtime(endTime);
                l3TestRequest.setReporttype(reportType);
        }
        catch (Exception e){
            logger.error("Exception while creating ");
        }
        return l3TestRequest;
    }

    protected boolean didScenarioPass(Element scenario){
        if(scenario==null){
            logger.error("didScenarioPass() - scenario is full");
            return false;
        }
        if(scenario.getSteps()==null){
            logger.error("didScenarioPass() - scenario.steps is null.scenario = {}", scenario.name);
            return false;
        }
        boolean didAnyStepFail= scenario.getSteps().stream().anyMatch(p -> p.getResult()!=null && isStatusConsideredFailure(p.getResult().getStatus()));
        return !didAnyStepFail;
    }

    protected boolean isStatusConsideredFailure(String status){
        return "failed".equals(status) || "undefined".equals(status);
    }


    protected List<Feature> deserializeCucumberJsonFile(String jsonPath){
        Type returnType = new TypeToken<List<Feature>>(){}.getType();
        try(FileInputStream fis= new FileInputStream(jsonPath)){
            return new Gson().fromJson(new InputStreamReader(fis),returnType);
        }
        catch(FileNotFoundException fileNotFoundException){
            logger.warn("deserializeCucumberJsonFile(), file-not-found exception, try loading resource folder (uni tests trigger this) ");
            return deserializeCucumberJsonResourceFile(jsonPath,returnType);
        }
        catch(Exception e){
            logger.error("Error loading json results=" + jsonPath);
            throw new RuntimeException(e);
        }

    }

    protected List<Feature> deserializeCucumberJsonResourceFile(String jsonPath,Type returnType){
        Resource resource = new ClassPathResource(jsonPath);
        try{
            return new Gson().fromJson(new InputStreamReader(resource.getInputStream()),returnType);
        }
        catch (Exception e){
            logger.error("Error trying to load json results= "+ jsonPath);
            throw new RuntimeException(e);
        }
    }

    private String getFinalJsonContent(String jsonPath, String env, String buildNbr,String testRunBuildNumber,
                                       TestResult testCounts,long startTime, long endTime,String testGroupId,String reportType, boolean finalize){
     String jsonFileContent = null;
     String jsonContent;
     if( !StringUtils.isEmpty(jsonPath)){
         File f = new File(jsonPath);
         try {
             byte[] bytes= Files.readAllBytes(f.toPath());
             jsonFileContent= new String(bytes , "UTF-8");
         }
         catch (Exception e){
             logger.error("error while reading json content {} : " + e);
         }

     }
     jsonContent="{"+"\n";
     jsonContent+="\"testgroupid\""+":"+"\""+testGroupId+"\""+","+"\n";
     jsonContent+="\"envname\""+":"+"\""+ env+ "\""+","+"\n";
     jsonContent+="\"buildnbr\""+":"+"\""+buildNbr+"\""+","+"\n";
     jsonContent+="\"systestbuildnbr\""+ ":"+"\""+sysTestBuildNumber+"\"" +","+"\n";
     jsonContent+="\"testrunbuildnbr\""+":"+ "\""+testRunBuildNumber+"\""+","+"\n";
     jsonContent+="\"machinename\""+":"+"\""+getHostName()+"\""+","+"\n";
     jsonContent+="\"totaltestcnt\""+":"+"\""+testCounts.getTotalTests()+"\""+","+"\n";
     jsonContent+="\"totalsuccessnt\""+":"+"\""+testCounts.getPassCount()+"\""+","+"\n";
     jsonContent+="\"totalfailcnt\""+":"+"\""+testCounts.getFailCount()+"\""+","+"\n";
     jsonContent+="\"updatedate\""+":"+"\""+"\""+","+"\n";
     jsonContent+="\"starttime\""+":"+"\""+startTime+"\""+","+"\n";
     jsonContent+="\"endtime\""+ ":"+"\""+endTime+"\""+","+"\n";
     jsonContent+="\"reporttype\""+":"+"\""+reportType+"\""+","+"\n";
     jsonContent+="\"finalized\""+":"+"\""+finalize+"\""+","+"\n";
     jsonContent+="\"features\""+":"+jsonContent+"\n";
     jsonContent+="}"+"\n";
     return jsonContent;

    }

    private static String getHostName(){
        InetAddress ip;
        String hostname="";
        try{
            ip=InetAddress.getLocalHost();
            hostname=ip.getHostName();
        }
        catch(Exception e){
            logger.error("Error while getting host name : " +e);
        }
        return hostname;
    }

    public void startTestRun(String testGroupId){
        if(testGroupId==null || testGroupId.trim().isEmpty()){
            testGroupId= UUID.randomUUID().toString();
        }
        L3ProgressUpdate.getL3TestGroupId().setTestGroupId(testGroupId);
    }

    public void broadcastScenarioCompletion(Scenario scenario){
        if(StringUtils.isEmpty(L3ProgressUpdate.getL3TestGroupId().getTestGroupId())){
            startTestRun(null);
        }

        try{
            logger.info("Update scenario completion to test- central");
            TestResult ts= new TestResult();
                ts.setPassCount((!scenario.isFailed()) ?1:0);
                ts.setFailCount((scenario.isFailed())?1:0);
            L3TestRequest req=  temprorySetTestCentralL3TestRequestObject(null,null,null,null,ts,0,0,
                    L3ProgressUpdate.getL3TestGroupId().getTestGroupId(),null,true);
            l3ResultService.updateScenario(req);

            /*
            // String testcentralUrl=String.format(" ");
               //  UriComponentsBuilder builder= UriComponentsBuilder.fromHttpUrl(testcentralUrl);
            String finalFileContent = getFinalJsonContent(null,null,null,null,ts,0,0,
                    L3ProgressUpdate.getL3TestGroupId().getTestGroupId(),null, true);
            Gson gson = new Gson();
            JsonElement element= gson.fromJson(finalFileContent,JsonElement.class);
            JsonObject jsonObject= element.getAsJsonObject();
            HttpHeaders httpHeaders= new HttpHeaders();
            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
            HttpEntity<String> entity = new HttpEntity<>(jsonObject.toString(),httpHeaders);
            AsyncRestTemplate template = new AsyncRestTemplate();
            template.postForEntity(builder.build().toUri(),entity,Void.class);*/
        }
        catch(Exception e){
            logger.error("sendUpdateToTestCentral() failed, url={} error{} ",e);
        }

    }






}
