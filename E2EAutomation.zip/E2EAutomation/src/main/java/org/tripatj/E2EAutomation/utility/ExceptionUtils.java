package org.tripatj.E2EAutomation.utility;

public class ExceptionUtils {
    public ExceptionUtils(){

    }
    public static RuntimeException convertToRuntimeException(Exception e){
        return e instanceof RuntimeException ? (RuntimeException) e: new RuntimeException(e);
    }

    public static RuntimeException newRunTimeException(String exceptionMessage){
        return new RuntimeException(exceptionMessage);
    }
}
