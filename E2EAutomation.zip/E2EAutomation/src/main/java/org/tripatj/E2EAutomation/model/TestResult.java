package org.tripatj.E2EAutomation.model;

public class TestResult {
    private int passCount=0;
    private int failCount=0;
    private String failureMessage;
    private String infoMessage;
    private String runStatus;
    private String resultObjects;

    public void incrementPassCount(){
        this.passCount++;
    }
    public void incrementFailedCount(){
        this.failCount++;
    }

    public int getPassCount() {
        return passCount;
    }

    public void setPassCount(int passCount) {
        this.passCount = passCount;
    }

    public int getFailCount() {
        return failCount;
    }

    public void setFailCount(int failCount) {
        this.failCount = failCount;
    }

    public String getFailureMessage() {
        return failureMessage;
    }

    public void setFailureMessage(String failureMessage) {
        this.failureMessage = failureMessage;
    }

    public String getInfoMessage() {
        return infoMessage;
    }

    public void setInfoMessage(String infoMessage) {
        this.infoMessage = infoMessage;
    }

    public String getRunStatus() {
        return runStatus;
    }

    public void setRunStatus(String runStatus) {
        this.runStatus = runStatus;
    }

    public String getResultObjects() {
        return resultObjects;
    }

    public void setResultObjects(String resultObjects) {
        this.resultObjects = resultObjects;
    }
    public int getTotalTests(){
        return getPassCount() + getFailCount();
    }


}
