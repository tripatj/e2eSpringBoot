package org.tripatj.E2EAutomation.testCentral.model;

import java.util.Date;

public class TestL3Result {


    private String testgroupid="";
    private String envname="";
    private String buildnbr="";
    private String systestbuildnbr= "";
    private String testrunbuildnbbr="";
    private String machinename = "";
    private long totaltestcnt=0;
    private long totalsuccesscnt=0;
    private long totalfailcnt=0;
    private Date starttime;
    private Date endtime;
    private long elapsetimeinMilliSeconds=0;
    private Date updatedate;
    private String cucumberreportPath;
    private String reporttype;

    public String getTestgroupid() {
        return testgroupid;
    }

    public void setTestgroupid(String testgroupid) {
        this.testgroupid = testgroupid;
    }

    public String getEnvname() {
        return envname;
    }

    public void setEnvname(String envname) {
        this.envname = envname;
    }

    public String getBuildnbr() {
        return buildnbr;
    }

    public void setBuildnbr(String buildnbr) {
        this.buildnbr = buildnbr;
    }

    public String getSystestbuildnbr() {
        return systestbuildnbr;
    }

    public void setSystestbuildnbr(String systestbuildnbr) {
        this.systestbuildnbr = systestbuildnbr;
    }

    public String getTestrunbuildnbbr() {
        return testrunbuildnbbr;
    }

    public void setTestrunbuildnbbr(String testrunbuildnbbr) {
        this.testrunbuildnbbr = testrunbuildnbbr;
    }

    public String getMachinename() {
        return machinename;
    }

    public void setMachinename(String machinename) {
        this.machinename = machinename;
    }

    public long getTotaltestcnt() {
        return totaltestcnt;
    }

    public void setTotaltestcnt(long totaltestcnt) {
        this.totaltestcnt = totaltestcnt;
    }

    public long getTotalsuccesscnt() {
        return totalsuccesscnt;
    }

    public void setTotalsuccesscnt(long totalsuccesscnt) {
        this.totalsuccesscnt = totalsuccesscnt;
    }

    public long getTotalfailcnt() {
        return totalfailcnt;
    }

    public void setTotalfailcnt(long totalfailcnt) {
        this.totalfailcnt = totalfailcnt;
    }

    public Date getStarttime() {
        return starttime;
    }

    public void setStarttime(Date starttime) {
        this.starttime = starttime;
    }

    public Date getEndtime() {
        return endtime;
    }

    public void setEndtime(Date endtime) {
        this.endtime = endtime;
    }

    public long getElapsetimeinMilliSeconds() {
        return elapsetimeinMilliSeconds;
    }

    public void setElapsetimeinMilliSeconds(long elapsetimeinMilliSeconds) {
        this.elapsetimeinMilliSeconds = elapsetimeinMilliSeconds;
    }

    public Date getUpdatedate() {
        return updatedate;
    }

    public void setUpdatedate(Date updatedate) {
        this.updatedate = updatedate;
    }

    public String getCucumberreportPath() {
        return cucumberreportPath;
    }

    public void setCucumberreportPath(String cucumberreportPath) {
        this.cucumberreportPath = cucumberreportPath;
    }

    public String getReporttype() {
        return reporttype;
    }

    public void setReporttype(String reporttype) {
        this.reporttype = reporttype;
    }

}
