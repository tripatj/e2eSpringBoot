package org.tripatj.E2EAutomation.steps;

import cucumber.api.Scenario;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.context.SpringBootContextLoader;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.tripatj.E2EAutomation.config.BaseConfig;
import org.tripatj.E2EAutomation.service.BrowserService;
import org.tripatj.E2EAutomation.service.TestReportService;


@ContextConfiguration(
        loader = SpringBootContextLoader.class,
        classes={BaseConfig.class}
)
@WebAppConfiguration
public class BaseTags {

    private static final Logger logger= LoggerFactory.getLogger(BaseTags.class);
    private Scenario scenario;

    @Autowired
    BrowserService browserService;
    @Autowired
    TestReportService testReportService;

    @Value("${environment}")
    String environment;

    @Value("${orangeHRM.url}")
    String url;

    @Before
    public void initsetup( Scenario scenario) {
        this.scenario = scenario;
        logger.info("------------------------------------");
        logger.info("Before set up is Executing for Scenario: " + scenario.getName());
        logger.info("------------------------------------");
    }

    @Given("^User navigate to Application$")

       public void userNavigateToApplication() {
        logger.info("Before set up is completed for Scenario: " + scenario.getName());
                browserService.navigateUrl(url, scenario.getName()+"_"+environment);
             }

    @Then("^User close the browser$")
        public void userCloseTheBrowser() {

    }

    @After
    public void scenarioClosing( Scenario scenario) {
       // this.scenario=scenario;
        logger.info("=====================================================================================================");
        logger.info("Activity required after Scenario started : " + scenario.getName());
        logger.info("=====================================================================================================");
        browserService.embedScreenshot(scenario);
        browserService.closeBrowser();
        testReportService.broadcastScenarioCompletion(scenario);
        logger.info("=====================================================================================================");
        logger.info("Activity required after Scenario Completed : " + scenario.getName());
        logger.info("=====================================================================================================");

    }


}

