package org.tripatj.E2EAutomation.utility;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CommonFunctions {
    private static final Logger logger= LoggerFactory.getLogger(CommonFunctions.class);

    public static void sleep(int timeout){
        try{
            Thread.sleep(timeout);
        }
        catch(InterruptedException e){
            logger.error("Failure in selenium sleep - ",e);
        }
    }
}
