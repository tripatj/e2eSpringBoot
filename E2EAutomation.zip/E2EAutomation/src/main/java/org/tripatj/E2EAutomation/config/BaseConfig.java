package org.tripatj.E2EAutomation.config;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({"org.tripatj.E2EAutomation"})
public class BaseConfig {

   /* @Bean
    public MongoConverter mongoConverter(MongoDbFactory factory){
        DbRefResolver dbRefResolver = new DefaultDbRefResolver(factory);
        MappingMongoConverter mappingMongoConverter= new MappingMongoConverter(dbRefResolver, new MongoMappingContext());
        mappingMongoConverter.afterPropertiesSet();
        return mappingMongoConverter;
    }*/

}
