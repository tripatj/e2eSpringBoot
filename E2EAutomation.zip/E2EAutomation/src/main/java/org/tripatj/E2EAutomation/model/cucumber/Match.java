package org.tripatj.E2EAutomation.model.cucumber;

import java.util.List;

public class Match {
    public List<Argument> arguments;
    public String location;


    public List<Argument> getArguments() {
        return arguments;
    }

    public void setArguments(List<Argument> arguments) {
        this.arguments = arguments;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }






}
