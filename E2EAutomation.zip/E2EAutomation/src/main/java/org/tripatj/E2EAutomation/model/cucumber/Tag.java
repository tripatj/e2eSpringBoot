package org.tripatj.E2EAutomation.model.cucumber;

import java.math.BigDecimal;

public class Tag {

    public BigDecimal line;
    public String name;

    public BigDecimal getLine() {
        return line;
    }

    public void setLine(BigDecimal line) {
        this.line = line;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }




}
