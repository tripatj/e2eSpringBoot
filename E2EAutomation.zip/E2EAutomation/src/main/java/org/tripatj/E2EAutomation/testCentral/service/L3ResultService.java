package org.tripatj.E2EAutomation.testCentral.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.tripatj.E2EAutomation.testCentral.model.L3TestRequest;
import org.tripatj.E2EAutomation.testCentral.repository.L3ResultRepository;

@Service
public class L3ResultService {
    @Autowired
    L3ResultRepository l3ResultRepository;

    public void saveResults(L3TestRequest l3TestRequest){
      //  l3ResultRepository.saveL3Result(l3TestRequest);
    }

    public void updateScenario(L3TestRequest l3TestRequest){
       // l3ResultRepository.updateScenario(l3TestRequest);
    }
}
