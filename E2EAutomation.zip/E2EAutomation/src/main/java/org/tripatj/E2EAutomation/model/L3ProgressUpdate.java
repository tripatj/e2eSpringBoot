package org.tripatj.E2EAutomation.model;

import java.util.Objects;

public class L3ProgressUpdate {
    private static L3TestGroupId l3TestGroupId;
    private L3ProgressUpdate(){

    }

    public static synchronized L3TestGroupId getL3TestGroupId(){
        if(Objects.isNull(l3TestGroupId)){
            l3TestGroupId= new L3TestGroupId();
        }
        return l3TestGroupId;
    }
}
