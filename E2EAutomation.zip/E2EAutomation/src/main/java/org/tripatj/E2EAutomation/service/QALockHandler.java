package org.tripatj.E2EAutomation.service;


import org.apache.commons.io.FileUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.tripatj.E2EAutomation.utility.ExceptionUtils;

import java.io.File;
import java.io.IOException;

@Service
public class QALockHandler {
    private static final Logger logger = LoggerFactory.getLogger(QALockHandler.class);
    private static final String LOCK_FILE_PATH= FileUtils.getUserDirectoryPath()+"/e2etest.lock";

    public boolean doesQALockExist(){
        File lockFile = new File(LOCK_FILE_PATH);
        if(lockFile.exists()){
            logger.warn(" lock file path is {} And another test is already running ",LOCK_FILE_PATH);
            return true;
        }
        return false;
    }

    public void createQALockFile() throws IOException {
        //create the qa Lock File
        File lockFile= new File(LOCK_FILE_PATH);
        try{
            FileUtils.touch(lockFile);
        }
        catch (IOException e){
            logger.error("Unable to create L3 Test lock file");
            throw ExceptionUtils.convertToRuntimeException(e);
        }

    }

    public void deleteQALockFile(){
        File lockFile= new File(LOCK_FILE_PATH);
        if(lockFile.exists()){
            FileUtils.deleteQuietly(lockFile);
        }

    }


}
