package org.tripatj.E2EAutomation.utility;

public class Constants {
    public static final String TEST_STATUS_SUCCESS = "SUCCESS";
    public static final String TEST_STATUS_FAILURE = "FAILURE";
    public static final String TEST_STATUS_COMPLETED = "EXECUTION COMPLETED";

}
