package org.tripatj.E2EAutomation.pageClass;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.tripatj.E2EAutomation.utility.CommonFunctions;


import java.util.List;
import java.util.concurrent.TimeUnit;

public class CommonElementPage {

    private static final Logger logger = LoggerFactory.getLogger(CommonElementPage.class);
    private WebDriver driver=null;

    public CommonElementPage(WebDriver driver){
        this.driver= driver;
        PageFactory.initElements(driver,this);
    }

    public void verifyHeader(String sHeaderText){
        driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
        CommonFunctions.sleep(1000);
        boolean headertextMatch= false;
        logger.info("Header Text " + sHeaderText);
        String xpath= "//*[contains(text()," +" \'"+sHeaderText+"\'"+ ")]";
        List<WebElement> elements= driver.findElements(By.xpath(xpath));
        for(WebElement element: elements){
            logger.info("Element text "+ element.getText());
            if(element.getText().contains(sHeaderText)){
                headertextMatch=true;
                logger.info(sHeaderText + " screen is verified. ");
                break;
            }
        }
        Assert.assertTrue(sHeaderText + " screen is not verified. ", headertextMatch);
    }
}
