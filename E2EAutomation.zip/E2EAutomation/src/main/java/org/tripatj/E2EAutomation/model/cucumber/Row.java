package org.tripatj.E2EAutomation.model.cucumber;

import java.math.BigDecimal;
import java.util.List;

public class Row {

    public List<String> cells;
    public BigDecimal line;

    public List<String> getCells() {
        return cells;
    }

    public void setCells(List<String> cells) {
        this.cells = cells;
    }

    public BigDecimal getLine() {
        return line;
    }

    public void setLine(BigDecimal line) {
        this.line = line;
    }



}
