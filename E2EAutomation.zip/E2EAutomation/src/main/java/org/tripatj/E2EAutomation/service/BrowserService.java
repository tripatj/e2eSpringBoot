package org.tripatj.E2EAutomation.service;

import cucumber.api.Scenario;
import org.apache.commons.lang3.StringUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.LocalFileDetector;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.util.concurrent.TimeUnit;


@Service
public class BrowserService {

    @Value("${browser}")
    private String browser;

    @Value("${selenium.driver.remoteDriverPath}")
    private String remoteDriverPath;

    @Value("${selenium.driver.localDriverPath}")
    private String localDriverPath;

    @Value("${selenium.chrome.driver.name}")
    private String chromeDriverName;

    @Value("${saucelabs.username}")
    private String sauceLabsUserName;

    @Value("${saucelabs.accesskey}")
    private String sauceLabsAccessKey;

    @Value("${saucelabs.host.path1}")
    private String sauceLabsHostPath;

    private static final Logger logger= LoggerFactory.getLogger(BrowserService.class);
    private static final String DISABLE_WEB_SECURITY="--disable-web-security";
    private static final String ACCEPT_INSECURE_CERTS="acceptInsecureCerts";
    private WebDriver driver;

    public WebDriver getDriver(){
        return getDriver(null);
    }

    public WebDriver getDriver(String name){
        if(driver!=null && ((RemoteWebDriver)driver).getSessionId()!=null){
            return driver;
        }
        else {
             if (StringUtils.isEmpty(sauceLabsUserName)){
                 launchBrowser();
             }
             else{
                 try{
                     launchSaucelabsBrowser(name);
                 }
                 catch(MalformedURLException e){
                    logger.error("Error in getting a saucelabs driver {}", e);
                 }
             }
        }
        return driver;
    }
    private void launchSaucelabsBrowser(String name) throws MalformedURLException{
        DesiredCapabilities caps = DesiredCapabilities.chrome();
            caps.setCapability("platform", "Windows 10");
            caps.setCapability("version", "66");
            //caps.setCapability("parentTunnel"," ");
         //   caps.setCapability("parentTunnel"," ");
            if(name!=null){
               caps.setCapability("name",name);
            }
          //  caps.setCapability("tunnelIdentifier","01_Prod_Internal_Site_Testing");
            caps.setCapability("maxDuration","3600");

            String sauceLabsURL="http://"+ sauceLabsUserName+":"+ sauceLabsAccessKey+"@"+sauceLabsHostPath;
        try{
            driver= new RemoteWebDriver(new URL(sauceLabsURL),caps);
        }
        catch(Exception ioe){
            logger.error("Error loading driver ::" + ioe.getMessage(),ioe);
        }
            driver.manage().window().maximize();
            ((RemoteWebDriver) driver).setFileDetector( new LocalFileDetector());
            driver.manage().timeouts().implicitlyWait(90,TimeUnit.SECONDS);

    }

    private void launchBrowser(){
        Path path=null;
        if(browser.equalsIgnoreCase("CHROME")){
            logger.info("using Chrome");
            try{
                //path =CommonUtils.moveFile(driverPath,localDirectoryLocForDriver,chromeDriverName);
              //  DesiredCapabilities capabilities = DesiredCapabilities.chrome();
                    ChromeOptions cliArgsCap= new ChromeOptions();

                        cliArgsCap.addArguments("test-type");
                        cliArgsCap.addArguments(DISABLE_WEB_SECURITY);
                        cliArgsCap.addArguments("--allow-running-insure-content");
                        cliArgsCap.addArguments("--web-security-false");
                        cliArgsCap.addArguments("--ignore-certificate-errors");
                        cliArgsCap.addArguments("--no-sandbox");
                        cliArgsCap.addArguments("start-maximized");
                        // cliArgsCap.setBinary("C:\\Users\\HP\\chromedriver.exe");
               // capabilities.setCapability(ChromeOptions.CAPABILITY,cliArgsCap);
                System.setProperty("webdriver.chrome.driver","C:\\Users\\HP\\chromedriver.exe ");

                //driver= new ChromeDriver(capabilities);
                driver= new ChromeDriver(cliArgsCap);
              //  driver= new ChromeDriver();
            }
            catch(Exception ioe){
                logger.error("Error loading driver ::" + ioe.getMessage(),ioe);
            }

        }
        driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
    }

    public void navigateUrl(String url){
        navigateUrl(url,null);
    }
    public void navigateUrl(String url,String name){
        getDriver(name);
        driver.get(url);
        logger.info("Application is launched with url {}", url);
    }
    public void closeBrowser(){
        if(driver!=null){
            logger.info("Closing browser");
            driver.quit();
            driver=null;
        }
    }

    public void embedScreenshot(Scenario scenario){
        if(driver!=null){
            try{
                scenario.write("<br>");
                String screenshot = ((org.openqa.selenium.TakesScreenshot)driver).getScreenshotAs(OutputType.BASE64);
                byte[] decoded= org.apache.commons.codec.binary.Base64.decodeBase64(screenshot.getBytes());
                scenario.embed(decoded,"image/png");
                logger.info("Screenshot has been taken for Scenario {}", scenario.getName());
            }
            catch(Exception e){
                logger.error("Exception while taking screenshot for Scenario {}",scenario.getName());
                new RuntimeException(e);
            }

        }

    }


}
