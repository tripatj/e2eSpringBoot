package org.tripatj.E2EAutomation.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.json.simple.JSONArray;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.tripatj.E2EAutomation.model.TestRequest;
import org.tripatj.E2EAutomation.model.TestResult;
import org.tripatj.E2EAutomation.utility.Constants;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Paths;
import java.util.*;
import java.util.concurrent.TimeUnit;

import static java.lang.System.currentTimeMillis;

@Service
public class TestRunnerService {
    private static final Logger ltest= LoggerFactory.getLogger(TestRunnerService.class);
    private static List<String> ALLCUCUMBERFEATUREFILES;
    private static List<String> CUCUMBEROPTIONGLUE;
    private static List<String> TAGS;
    private static List<String> ALLCUCUMBERFEATUREFILESRerun= Arrays.asList("@target/rerun.txt");
    private static final String TAG="--tags";
    private static final String CUCUMBER_PLUGIN="--plugin";
    private static final List<String> CUCUMBEROPTIONSPLUGIN= Arrays.asList(
            CUCUMBER_PLUGIN,"pretty",
            CUCUMBER_PLUGIN,"html:target/cucumber-html-report",
            CUCUMBER_PLUGIN,"json:target/cucumber.json",
            CUCUMBER_PLUGIN,"junit:target/cucumber.xml",
            CUCUMBER_PLUGIN, "rerun:target/rerun.txt");
    private static int RETRY_COUNT;
    private static final String RERUN_FILE_PREFIX="ReRun";
    private static int rerun;


    private static final String TARGET="target";
    private static final String TARGETPATH= Paths.get("").toAbsolutePath().toString()+ File.separator+TARGET+File.separator;
    private static final String CUCUMBER_JSON="cucumber.json";
    private static final String FINALJSONFILEPATH=TARGETPATH+CUCUMBER_JSON;
    private static final String INTERMEDIATEFOLDERPATH= TARGETPATH+"intermediateJsonFiles"+File.separator;
    private static final String MAINCUCUMBERJSON=INTERMEDIATEFOLDERPATH+"MainRuncucumber.json";
    private static  final String TEST_STATUS_EXECUTING="EXECUTING";
    private  boolean runInProgress= false;
    private boolean isRunInProgress() {
        return runInProgress;
    }
    @Autowired
    private TestReportService testReportService;

    @Autowired
    private QALockHandler qaLockHandler;

    @Value("${environment}")
    private String environment;

    @Value("${build.no}")
    private String buildNumber;

    @Value("${test.report}")
    private String reportType;

    public void runTests(TestRequest request, TestResult testResult){
        ltest.info("L3Automation suite triggered for {} ", request.toString());
        runInProgress=true;

        ltest.info("L3 Automation suite trigger for {}",request.toString());
        if(! (request.getFeatureName().equals("") || request.getFeatureName().equals("string"))){
            ALLCUCUMBERFEATUREFILES=Arrays.asList("classpath:org.tripatj.E2EAutomation.featureFiles"+request.getFeatureName());
            ltest.info("ALLCUCUMBERFEATUREFILES -> {}", ALLCUCUMBERFEATUREFILES);
        }
        else{
            ALLCUCUMBERFEATUREFILES=Arrays.asList("classpath:org.tripatj.E2EAutomation.featureFiles");
            ltest.info("ALLCUCUMBERFEATUREFILES -> {}", ALLCUCUMBERFEATUREFILES);
        }

        if( ! (request.getGlue().equals("") || request.getGlue().equals("string"))){
            CUCUMBEROPTIONGLUE=Arrays.asList("--glue","classpath:org.tripatj.E2EAutomation.steps"+request.getGlue());
            ltest.info("CUCUMBEROPTIONGLUE -> {}", CUCUMBEROPTIONGLUE);
        }
        else{
            CUCUMBEROPTIONGLUE=Arrays.asList("--glue","classpath:org.tripatj.E2EAutomation.steps");
            ltest.info("CUCUMBEROPTIONGLUE -> {}", CUCUMBEROPTIONGLUE);
        }

        if(!(request.getTag().equals("") || request.getTag().equals("string"))){
            TAGS=Arrays.asList(TAG,request.getTag());
            ltest.info("TAGS -> {}",TAGS);
        }
        else{
            TAGS=Arrays.asList(TAG,"~@Ignore");
            ltest.info("TAGS -> {}",TAGS);

        }
        RETRY_COUNT=request.getRetryCount();
        rerun=0;

        ltest.info("Value of retryCount -> {}",RETRY_COUNT);
        ltest.info("Initial Value of rerun at the start of test-> {}",rerun);
        testResult.setRunStatus(TEST_STATUS_EXECUTING);
     //   testReportService.startTestRun("");

        long start= currentTimeMillis();
        String buildStts= Constants.TEST_STATUS_SUCCESS;
        try{
            String testRunBuildNo= getBuildNumber(environment);
       //     testReportService.addEmptyRecordInTestCentral(start,environment,getApplicationBuildNumber(),testRunBuildNo,this.reportType);
            cleanupJsonFile();
            boolean isSuccess = runTestsUpdated();
            checkForNoOfRerunJsonFiles();
         //   final TestResult tempResult= testReportService.saveTestResultToTestCentral(start,environment,getApplicationBuildNumber(),testRunBuildNo,this.reportType);
           /* buildStts=(isSuccess && StringUtils.isEmpty(tempResult.getFailureMessage()))? Constants.TEST_STATUS_SUCCESS:Constants.TEST_STATUS_FAILURE;
            tempResult.setFailCount(tempResult.getPassCount());
            tempResult.setPassCount(tempResult.getPassCount());
            tempResult.setFailureMessage(tempResult.getFailureMessage());*/
           // GenerateMasterThoughtReport.generateReport();
        }
        catch(Exception e){
            ltest.error("Exception in running tests {}",e);
            buildStts= Constants.TEST_STATUS_FAILURE;
            throw new RuntimeException(e);
        }
        finally {
            //qaLockHandler.deleteQALockFile();
            testResult.setRunStatus(Constants.TEST_STATUS_COMPLETED);
        }
        long duration= currentTimeMillis()-start;
        ltest.info("Test duration is {} minutes", TimeUnit.MILLISECONDS.toMinutes(duration));
        ltest.info("E2E Automation suite execution completed. Runstatus:{} ", buildStts);
        testResult.setInfoMessage(String.format("%s (pass=%d, fail%d) elapsed: %d min %d sec(build %s )",
                buildStts,
                testResult.getPassCount(),
                testResult.getFailCount(),
                TimeUnit.MILLISECONDS.toMinutes(duration),
                TimeUnit.MILLISECONDS.toSeconds(duration) - TimeUnit.MINUTES.toSeconds(TimeUnit.MILLISECONDS.toMinutes(duration)), buildNumber));
    }

    private String getApplicationBuildNumber() throws URISyntaxException{
        // dummy implementation of getting Application's latest build
        /*String url = "";
        String applicationURi= "";
        try {
            URI uri= new URI(applicationURi + "/endPoint");
            url= uri.toString();
            ltest.debug("Get latest build versio of Application {}", uri);
            ResponseEntity<String> response= new RestTemplate().getForEntity(uri,String.class);
            ltest.info(" Latest build version = {}", response.getBody());
            return response.getBody();
        }
        catch (Exception ex){
            ltest.error(" Exception while getting applcation build number" + ex);
            return "?";
        }*/
        return "";
    }

    private List<String> getCucumberOptions(){
        List<String> cucumberOptions = new ArrayList<>();
        cucumberOptions.addAll(CUCUMBEROPTIONSPLUGIN);
        cucumberOptions.addAll(CUCUMBEROPTIONGLUE);
        cucumberOptions.add("--strict");
        if(rerun==0){
            cucumberOptions.addAll(TAGS);
            cucumberOptions.addAll(ALLCUCUMBERFEATUREFILES);
            ltest.info("Feature File Name -> {}",ALLCUCUMBERFEATUREFILES);
        }
        else if (rerun > 0 && rerun <=RETRY_COUNT){
            cucumberOptions.addAll(ALLCUCUMBERFEATUREFILESRerun);
        }
        else{
            ltest.error("Invalid getCucumberOptions");
        }
        return cucumberOptions;
    }

    //dummy method created
    private String getBuildNumber(String ipsEnvName){
      /*  String testCentralURL=" ";
        List<String> testL3Results=null;
        try{
            URI uri= new URI(testCentralURL+"/endPoint");
            uri.toString();
            ltest.debug("Get buildVersion {}", uri);
            ResponseEntity<List<String>> response= new RestTemplate().exchange(uri, HttpMethod.GET, null, new ParameterizedTypeReference<List<String>>() {});
            testL3Results=response.getBody();
            for (String test : testL3Results){
                //traverse and get runtimr build no the actual enviorement name from some application
                 if (ipsEnvName.equals test.env){
                 //int buildNo= getNewbbuildNo();
                 }
            }
            //return buildNo.toString();
        }
        catch (NumberFormatException e){
           return "1";
        }
        catch (Exception e){
            ltest.error("Error while  gettting buikld ", e );
            return null;
        }*/
        return "local dev";
    }

    private String[] setupCucumberOptions(){
        List<String> cucumberOptions;
        String [] cucumberOptionsArray;
        cucumberOptions=getCucumberOptions();
        cucumberOptionsArray=cucumberOptions.toArray(new String[cucumberOptions.size()]);
        return cucumberOptionsArray;
    }
    private boolean runTestsUpdated(){
            boolean isSuccess = false;
            String[] cucumberOptionsArray;
            try{
                ltest.info("current Value of rerun before MainRun -> {}", rerun);
                cucumberOptionsArray=setupCucumberOptions();
                isSuccess=executeCucumber(cucumberOptionsArray);
                jsonForEachRun("MainRun");
                if(!isSuccess){
                    for(int i=1; i<=RETRY_COUNT; i++){
                        rerun++;
                        ltest.info("Current Value of rerun after MainRun -> {}", rerun);
                        cucumberOptionsArray=setupCucumberOptions();
                        //updateFailureScenario();
                        isSuccess=executeCucumber(cucumberOptionsArray);
                        jsonForEachRun(RERUN_FILE_PREFIX+rerun);
                        if(isSuccess){
                            break;
                        }

                    }
                    ltest.info("Final Value of rerun {}", rerun);
                }
            }
            catch(Exception e){
                ltest.error("Exception while setUp Cucumber Options");
                throw new RuntimeException(e);
            }
       return isSuccess;
    }

    public boolean executeCucumber(String[] cucumberOptionsArrays) throws IOException {
        ltest.debug("Before calling cucumber");
        byte exitStatus= cucumber.api.cli.Main.run(cucumberOptionsArrays,Thread.currentThread().getContextClassLoader());
        return exitStatus==0;
    }

    private static void jsonForEachRun(String jsonFileName) throws IOException {
        File jsonFile = new File(FINALJSONFILEPATH);
        FileUtils.copyFile(jsonFile, new File(INTERMEDIATEFOLDERPATH+jsonFileName+CUCUMBER_JSON));
        ltest.info("Name of cucumber file -> {}", INTERMEDIATEFOLDERPATH+jsonFileName+CUCUMBER_JSON);
    }

    private static void cleanupJsonFile(){
        File intermeadiateFolder= new File(INTERMEDIATEFOLDERPATH);
        if( ! intermeadiateFolder.getParentFile().exists()){
            intermeadiateFolder.getParentFile().mkdir();
        }
            intermeadiateFolder.mkdir();
        if(intermeadiateFolder!=null){
            for(File file : intermeadiateFolder.listFiles()){
                if(file.getName().endsWith((".json"))){
                    file.delete();
                }
            }
        }
    }

    private static void checkForNoOfRerunJsonFiles() throws IOException{
        File mainRunCucumberJson= new File(MAINCUCUMBERJSON);
        // to Keep main Json file (MainRunCucumber)untouch in intermediate folder
        FileUtils.copyFile(mainRunCucumberJson,new File(FINALJSONFILEPATH));
        int count=1;
        File folder = new File(INTERMEDIATEFOLDERPATH);
        // Return file as well directory
        File[] fList= folder.listFiles();

        // if test is pass in the First Run so there is no rerun then copy mainRuncuumber for reporting
        for (File it: fList){
           if(fList.length==1 && it.getName().startsWith("MainRun")){
               ltest.info("All Scenario passed in the first Run");
           }
           else if (count <= RETRY_COUNT && it.getName().startsWith(RERUN_FILE_PREFIX)){
               String rerunJson = INTERMEDIATEFOLDERPATH+RERUN_FILE_PREFIX+count+CUCUMBER_JSON;
               JSONArray replacedJson =jsonFileToJsonObject(rerunJson,FINALJSONFILEPATH);
               if(null!= replacedJson){
                   jsonObjToJsonFile(replacedJson);
               }
                count++;
           }
        }

    }

    private static void jsonObjToJsonFile(JSONArray replacedJson){
        try{
            FileUtils.writeStringToFile( new File(FINALJSONFILEPATH),replacedJson.toJSONString());
        }
        catch(IOException e){
            ltest.error("Unable to write into FinalJsonFilePath",e);
        }
    }

    //Update each value under Elements Object Node
    private static void replaceScenarioValue(JsonNode toBereplaceAd, JsonNode replaceAdInto){
       Iterator<Map.Entry<String,JsonNode>> toBeReplacedJNode=toBereplaceAd.fields();
       Iterator<Map.Entry<String,JsonNode>> gongToBeRplcJNode=replaceAdInto.fields();
try {
    while (toBeReplacedJNode.hasNext()) {
        Map.Entry<String, JsonNode> toBeEntry = toBeReplacedJNode.next();
        while (gongToBeRplcJNode.hasNext()) {
            Map.Entry<String, JsonNode> entry = gongToBeRplcJNode.next();

            if (entry.getKey().equals(toBeEntry.getKey())) {
                entry.setValue(toBeEntry.getValue());
                break;
            }
        }

    }
}
catch (Exception e){
    ltest.error("Exception in replaceScenarioValue {}" , e);
    new RuntimeException(e);

}
    }

    private static void traverseScenarios(JsonNode elementKey1, JsonNode elementKey2){
      String toBeTestScenarioId= "";
      String intoTestScenarioId= "" ;
      try {

          for (int i = 0; i < elementKey1.size(); i++) {
              Iterator<Map.Entry<String, JsonNode>> tobeJson = elementKey1.get(i).fields();
              while (tobeJson.hasNext()) {
                  Map.Entry<String, JsonNode> toBeSearchScen = tobeJson.next();
                  if (toBeSearchScen.getKey().equals("id")) {
                      toBeTestScenarioId = toBeSearchScen.getValue().asText();
                      break;
                  }
              }

              for (int j = 0; j < elementKey2.size(); j++) {
                  Iterator<Map.Entry<String, JsonNode>> intoJson = elementKey2.get(j).fields();
                  while (intoJson.hasNext()) {
                      Map.Entry<String, JsonNode> intoSearchScen = intoJson.next();
                      if (intoSearchScen.getKey().equals("id")) {
                          intoTestScenarioId = intoSearchScen.getValue().asText();
                      }
                  }

                  if (toBeTestScenarioId.equals(intoTestScenarioId)) {
                      replaceScenarioValue(elementKey1.get(i), elementKey2.get(j));
                  }
              }
          }
      }
      catch (Exception e ){
          ltest.error("Error in traverseScenarios {}" , e);
          new RuntimeException(e);
      }
    }




    private static JSONArray jsonFileToJsonObject(String toBeSearchjson,String intoSearchJson){
        ObjectMapper mapper;
        JsonNode toBeRePlaced = null;
        JsonNode intoReplaced = null;
        JSONArray jArray1 =null;
        JSONArray jArray2;

        JSONParser parser = new JSONParser();
        mapper = new ObjectMapper();
        try{
            Object obj2= parser.parse( new FileReader(toBeSearchjson));
            Object obj1= parser.parse( new FileReader(intoSearchJson));
            jArray2=(JSONArray) obj2;
            jArray1=(JSONArray) obj1;

            for ( int t=0; t< jArray2.size();t++){
                toBeRePlaced=mapper.readTree(jArray2.get(t).toString());
                for(int i=0; i< jArray1.size();i++){
                    intoReplaced=mapper.readTree(jArray1.get(i).toString());
                    traverseFeatures(toBeRePlaced,intoReplaced);
                    jArray1.set(i,intoReplaced);
                }
            }

        }
        catch(ParseException p){
            ltest.error("Parsing Exception",p);
        }
        catch(Exception t){
            ltest.error("Issue in JArray",t);
        }
        return jArray1;

    }


    private static void traverseFeatures(JsonNode jsonNodeTobeTraverse, JsonNode jsonNodeIntoTraverse){
        JsonNode toBeElementKey=null;
        JsonNode intoElementKey=null;
try {

    Iterator<Map.Entry<String, JsonNode>> it1 = jsonNodeTobeTraverse.fields();
    Iterator<Map.Entry<String, JsonNode>> it2 = jsonNodeIntoTraverse.fields();

    while (it1.hasNext()) {
        Map.Entry<String, JsonNode> jsonNode1 = it1.next();

        if (jsonNode1.getKey().equals("elements")) {
            toBeElementKey = jsonNode1.getValue();
        }
        //featureLevelID
        if (jsonNode1.getKey().equals("id")) {
            while (it2.hasNext()) {
                Map.Entry<String, JsonNode> jsonNode2 = it2.next();
                if (jsonNode2.getKey().equals("elements")) {
                    intoElementKey = jsonNode2.getValue();
                }
                if (jsonNode2.getKey().equals("id")) {
                    if (jsonNode2.getValue().equals(jsonNode1.getValue()) && null != toBeElementKey && null != intoElementKey) {
                        traverseScenarios(toBeElementKey, intoElementKey);
                        break;
                    }

                }
            }
        }
    }
}
catch(Exception e ){
    ltest.error("Exception Raise in traverseFeatures {}" , e);
    new RuntimeException(e);
}

    }











}
