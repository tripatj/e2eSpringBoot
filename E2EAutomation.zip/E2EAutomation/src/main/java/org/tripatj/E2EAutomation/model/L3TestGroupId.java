package org.tripatj.E2EAutomation.model;

public class L3TestGroupId {

    private  String testGroupId;

    public String getTestGroupId() {
        return testGroupId;
    }

    public void setTestGroupId(String testGroupId) {
        this.testGroupId = testGroupId;
    }



}
