package org.tripatj.E2EAutomation.model.cucumber;

import java.math.BigDecimal;
import java.util.List;

public class Step {
    public BigDecimal line;
    public String name;
    public Match match;
    public List<Row> rows;
    public List<BigDecimal> matchedcolumns;
    public String keyword;
    public Result result;

    public Result getResult() {
        return result;
    }

    public void setResult(Result result) {
        this.result = result;
    }

    public BigDecimal getLine() {
        return line;
    }

    public void setLine(BigDecimal line) {
        this.line = line;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Match getMatch() {
        return match;
    }

    public void setMatch(Match match) {
        this.match = match;
    }

    public List<Row> getRows() {
        return rows;
    }

    public void setRows(List<Row> rows) {
        this.rows = rows;
    }

    public List<BigDecimal> getMatchedcolumns() {
        return matchedcolumns;
    }

    public void setMatchedcolumns(List<BigDecimal> matchedcolumns) {
        this.matchedcolumns = matchedcolumns;
    }

    public String getKeyword() {
        return keyword;
    }

    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }



}
