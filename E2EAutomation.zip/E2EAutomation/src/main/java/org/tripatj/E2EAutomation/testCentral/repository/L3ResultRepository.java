package org.tripatj.E2EAutomation.testCentral.repository;

import org.springframework.stereotype.Repository;

@Repository
public class L3ResultRepository {/*
    private static final Logger logger = LoggerFactory.getLogger(L3ResultRepository.class);
    private static final String TEST_GROUP_ID = "testgroupid";
    private static final String TEST_L3_RESULT = "TEST_L3_RESULT";
    private static final String CUCUMBER_REPORT_RELATIVE_PATH = "/cucumber-html-report/overview-features.html";

    @Autowired
    private MongoConverter mongoConverter;

    @Autowired
    private MongoTemplate mongoTemplateTestCentral;

    public void saveL3Result(L3TestRequest l3TestRequest) {
        logger.info("l3TestRequest() {}", l3TestRequest.toString());
        if (l3TestRequest == null) {
            throw new IllegalArgumentException("saveL3Result() l3TestRequest is null");
        }
        TestL3Result testL3Result = createTestL3ResultForRequest(l3TestRequest);
        // need to add later
        //TestCucumberResult l3cucumberResult= createDetailTestIntegRunGroupForRequest(l3TestRequest);

        saveTestL3ResultToDB(testL3Result);
        //saveTestL3CucumberResultToDB(l3CucumberResult);

    }

    protected void saveTestL3ResultToDB(TestL3Result testL3Result) {
        Query query = new Query().addCriteria(Criteria.where(TEST_GROUP_ID).is(testL3Result.getTestgroupid()));

        List<TestL3Result> results = mongoTemplateTestCentral.find(query, TestL3Result.class, TEST_L3_RESULT);

        TestL3Result toSave = results.stream()
                .map(found -> {
                    found.setTotaltestcnt(testL3Result.getTotaltestcnt());
                    found.setTotalsuccesscnt(testL3Result.getTotalsuccesscnt());
                    found.setTotalfailcnt(testL3Result.getTotalfailcnt());
                    found.setEndtime(testL3Result.getEndtime());
                    found.setElapsetimeinMilliSeconds(testL3Result.getElapsetimeinMilliSeconds());
                    found.setUpdatedate(testL3Result.getUpdatedate());
                    found.setCucumberreportPath(testL3Result.getCucumberreportPath());
                    found.setReporttype(testL3Result.getReporttype());
                    return found;
                })
                .findFirst().orElse(testL3Result);
        *//* need to check why write() method not accepting Document Object
       Document dbdoc= new Document();
       mongoTemplateTestCentral.getConverter().write(toSave,dbdoc);*//*

        DBObject dbdoc = new BasicDBObject();
        mongoTemplateTestCentral.getConverter().write(toSave, dbdoc);
        mongoTemplateTestCentral.save(dbdoc, TEST_L3_RESULT);

    }

    protected TestL3Result createTestL3ResultForRequest(L3TestRequest l3TestRequest) {
        TestL3Result testL3Result = new TestL3Result();
                    testL3Result.setTestgroupid(l3TestRequest.getTestgroupid());
                    testL3Result.setTestgroupid(l3TestRequest.getTestgroupid());
                    testL3Result.setEnvname(l3TestRequest.getEnvname());
                    testL3Result.setBuildnbr(l3TestRequest.getBuildnbr());
                    testL3Result.setSystestbuildnbr(l3TestRequest.getSystestbuildnbr());
                    testL3Result.setTestrunbuildnbbr(l3TestRequest.getTestrunbuildnbbr());
                    testL3Result.setMachinename(l3TestRequest.getMachinename());
                    testL3Result.setTotalsuccesscnt(l3TestRequest.getTotalsuccesscnt());
                    testL3Result.setTotalfailcnt(l3TestRequest.getTotalfailcnt());
                    testL3Result.setTotaltestcnt(l3TestRequest.getTotaltestcnt());
                    testL3Result.setStarttime(new Date(l3TestRequest.getStarttime()));
                    testL3Result.setEndtime(l3TestRequest.getEndtime() > 0 ? new Date(l3TestRequest.getEndtime()) : null);
                    testL3Result.setElapsetimeinMilliSeconds(getelapsedTimeinMilliSeconds(testL3Result.getStarttime(), testL3Result.getEndtime()));
                    testL3Result.setUpdatedate(new Date());
                    testL3Result.setCucumberreportPath(l3TestRequest.getTestgroupid() + CUCUMBER_REPORT_RELATIVE_PATH);
                    testL3Result.setReporttype(l3TestRequest.getReporttype());
        return testL3Result;
    }

    public static long getelapsedTimeinMilliSeconds(Date startTime, Date endTime) {
        long elapsedTimeinMilliSeconds = 0L;
        if (startTime != null && endTime != null) {
            elapsedTimeinMilliSeconds = endTime.getTime() - startTime.getTime();
        }
        return elapsedTimeinMilliSeconds;
    }

    public synchronized void updateScenario(L3TestRequest request) {
        Query query = new Query().addCriteria(Criteria.where(TEST_GROUP_ID).is(request.getTestgroupid()));
      List<TestL3Result> results = mongoTemplateTestCentral.find(query,TestL3Result.class,TEST_L3_RESULT);
      TestL3Result toSave= results.stream()
              .map( found ->{
                  found.setTotalsuccesscnt(found.getTotalsuccesscnt()+ request.getTotalsuccesscnt());
                  found.setTotalfailcnt(found.getTotalfailcnt()+request.getTotalfailcnt());
                  found.setTotaltestcnt(found.getTotaltestcnt()+1);
                  found.setElapsetimeinMilliSeconds((System.currentTimeMillis()- found.getStarttime().getTime()));
                  return found;
              })
              .findFirst().orElse(null);
      if(null!= toSave){
             *//* need to check why write() method not accepting Document Object
                   Document dbdoc= new Document();
       mongoTemplateTestCentral.getConverter().write(toSave,dbdoc);*//*

          DBObject dbDoc = new BasicDBObject();
          mongoTemplateTestCentral.getConverter().write(toSave,dbDoc);
          mongoTemplateTestCentral.save(dbDoc,TEST_L3_RESULT);
      }
      logger.info("updateScenario() Completed ");

    }

*/
}


