package org.tripatj.E2EAutomation.testCentral.model;

import org.tripatj.E2EAutomation.model.cucumber.Feature;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class L3TestRequest {

    private String testgroupid="";
    private String envname="";
    private String buildnbr="";
    private String systestbuildnbr= "";
    private String testrunbuildnbbr="";
    private String machinename = "";
    private long totaltestcnt=0;
    private long totalsuccesscnt=0;
    private long totalfailcnt=0;
    private Date updatedate;
    private long starttime;
    private long endtime;
    private String reporttype;
    private List<Feature> features = new ArrayList<>();
    public void addFileResults(List<Feature> fileResults){
        this.features.addAll(fileResults);
    }

    public String getTestgroupid() {
        return testgroupid;
    }

    public void setTestgroupid(String testgroupid) {
        this.testgroupid = testgroupid;
    }

    public String getEnvname() {
        return envname;
    }

    public void setEnvname(String envname) {
        this.envname = envname;
    }

    public String getBuildnbr() {
        return buildnbr;
    }

    public void setBuildnbr(String buildnbr) {
        this.buildnbr = buildnbr;
    }

    public String getSystestbuildnbr() {
        return systestbuildnbr;
    }

    public void setSystestbuildnbr(String systestbuildnbr) {
        this.systestbuildnbr = systestbuildnbr;
    }

    public String getTestrunbuildnbbr() {
        return testrunbuildnbbr;
    }

    public void setTestrunbuildnbbr(String testrunbuildnbbr) {
        this.testrunbuildnbbr = testrunbuildnbbr;
    }

    public String getMachinename() {
        return machinename;
    }

    public void setMachinename(String machinename) {
        this.machinename = machinename;
    }

    public long getTotaltestcnt() {
        return totaltestcnt;
    }

    public void setTotaltestcnt(long totaltestcnt) {
        this.totaltestcnt = totaltestcnt;
    }

    public long getTotalsuccesscnt() {
        return totalsuccesscnt;
    }

    public void setTotalsuccesscnt(long totalsuccesscnt) {
        this.totalsuccesscnt = totalsuccesscnt;
    }

    public long getTotalfailcnt() {
        return totalfailcnt;
    }

    public void setTotalfailcnt(long totalfailcnt) {
        this.totalfailcnt = totalfailcnt;
    }

    public Date getUpdatedate() {
        return updatedate;
    }

    public void setUpdatedate(Date updatedate) {
        this.updatedate = updatedate;
    }

    public long getStarttime() {
        return starttime;
    }

    public void setStarttime(long starttime) {
        this.starttime = starttime;
    }

    public long getEndtime() {
        return endtime;
    }

    public void setEndtime(long endtime) {
        this.endtime = endtime;
    }

    public String getReporttype() {
        return reporttype;
    }

    public void setReporttype(String reporttype) {
        this.reporttype = reporttype;
    }

    public List<Feature> getFeatures() {
        return features;
    }

    public void setFeatures(List<Feature> features) {
        this.features = features;
    }




}
