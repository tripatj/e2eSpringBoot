
package org.tripatj.E2EAutomation.steps;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Then;
import org.openqa.selenium.WebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.tripatj.E2EAutomation.pageClass.CommonElementPage;
import org.tripatj.E2EAutomation.pageClass.LoginPage;
import org.tripatj.E2EAutomation.service.BrowserService;


public class LoginSteps {
 @Autowired
 private BrowserService browserService;

 private WebDriver driver=null;
 private LoginPage login=null;
  private CommonElementPage commonElementPage = null;
  private Logger logger = LoggerFactory.getLogger(LoginSteps.class);



public LoginSteps(BrowserService browserService){
      this.browserService=browserService;
      driver=browserService.getDriver();
      login= new LoginPage(driver);
    commonElementPage= new CommonElementPage(driver);
}

    @And("^Enter User Name as \"([^\"]*)\" and Password as \"([^\"]*)\" and click on login$")
    public void enterUserNameAsAndPasswordAsAndClickOnLogin(String userName, String pwd) {
        login.getUserName().sendKeys(userName);
        login.getPassword_edt().sendKeys(pwd);
        login.getLogin_btn().click();
    }

    @Then("^User  should able to see \"([^\"]*)\" screen\\.$")
    public void userShouldAbleToSeeScreen(String screenName) {
        commonElementPage.verifyHeader(screenName);
        logger.info("Entering : User should able to see " + screenName + " message");
    }
}
