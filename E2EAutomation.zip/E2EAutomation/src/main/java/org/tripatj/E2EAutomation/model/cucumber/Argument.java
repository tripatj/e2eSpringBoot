package org.tripatj.E2EAutomation.model.cucumber;

import java.math.BigDecimal;

public class Argument {
    public String val;
    public BigDecimal offset;

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val;
    }

    public BigDecimal getOffset() {
        return offset;
    }

    public void setOffset(BigDecimal offset) {
        this.offset = offset;
    }




}
