package org.tripatj.E2EAutomation.api.controller;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.tripatj.E2EAutomation.model.TestRequest;
import org.tripatj.E2EAutomation.model.TestResult;
import org.tripatj.E2EAutomation.service.TestRunnerService;


import java.io.IOException;

@Api(value ="Retry cucumber Tests", description= "Operations for managing the Retry Web Execution Mechanism " )
@RestController
@RequestMapping("/v1/retryCucumberTests")
public class TestController {
    private static final Logger logger= LoggerFactory.getLogger(TestController.class);

    @Autowired
    private TestRunnerService testRunnerService;

    @ApiOperation(value = "Triggers retry Cucumber Tests")
    @RequestMapping(value = "/start", method= RequestMethod.POST)
    public void statCucumberTest(@RequestBody TestRequest testRequest) throws IOException {
        TestResult testResult= new TestResult();
        testRunnerService.runTests(testRequest,testResult);
    }


}
