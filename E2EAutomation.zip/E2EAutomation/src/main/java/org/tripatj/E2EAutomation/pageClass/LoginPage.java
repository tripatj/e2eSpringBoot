package org.tripatj.E2EAutomation.pageClass;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class LoginPage {

    WebDriverWait wait;

    @FindBy(name="txtUsername")
    private WebElement username_edt;

    @FindBy(id="txtPassword")
    private WebElement password_edt;

    @FindBy(id="btnLogin")
    private WebElement login_btn;

    public LoginPage(WebDriver driver) {
        PageFactory.initElements(driver,this);
        wait = new WebDriverWait(driver,60);
    }

    public WebElement getUserName(){
        return wait.until(ExpectedConditions.visibilityOf(username_edt));
    }

   public WebElement getPassword_edt(){
        return wait.until(ExpectedConditions.visibilityOf(password_edt));
   }

   public WebElement getLogin_btn(){
        return wait.until(ExpectedConditions.visibilityOf(login_btn));
   }

}
