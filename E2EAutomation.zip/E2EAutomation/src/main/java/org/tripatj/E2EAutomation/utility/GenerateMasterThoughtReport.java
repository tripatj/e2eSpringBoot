package org.tripatj.E2EAutomation.utility;

import net.masterthought.cucumber.Configuration;
import net.masterthought.cucumber.ReportBuilder;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import static java.lang.System.currentTimeMillis;

public class GenerateMasterThoughtReport {
    private static final Logger logger= LoggerFactory.getLogger(GenerateMasterThoughtReport.class);
    private static final String BASEPATH= "C:/code/springCucuSele/";
    private static final String TARGETPATH=BASEPATH+"target/";

    public static void main(String [] args){
        long start=currentTimeMillis();
        try{
            generateReport();
        }
        catch(Exception e){
            logger.error("Exception in running tests {}",e);
            throw new RuntimeException(e);
        }
            finally {

        }
    }


    public static void generateReport(){
        File reportOutputDirectory= new File(TARGETPATH+"cucumberReports");
        List<String> jsonFiles= checkAlljsonFiles(TARGETPATH);
        String projectName="MasterThought Report for Retry Mechanism Demo";
        Configuration configuration= new Configuration(reportOutputDirectory,projectName);
        ReportBuilder reportBuilder= new ReportBuilder(jsonFiles,configuration);
        reportBuilder.generateReports();

    }

    private static List<String> checkAlljsonFiles(String directory){
        List<String> jsonFiles = new ArrayList<>();
        File direct= new File(directory);
        for (File file : direct.listFiles()){
            if(file.getName().endsWith("cucumber.json")){
                jsonFiles.add(TARGETPATH+file.getName());

            }
        }
        return jsonFiles;
    }

}
