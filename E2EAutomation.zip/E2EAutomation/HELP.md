# Read Me First
The following was discovered as part of building this project:

* project uses 'org.tripatj.E2EAutomation'.

# Getting Started

### Reference Documentation
http://localhost:8061/E2EAutomation/swagger-ui.html
Ex: Request 


### Additional Links
These additional references should also help you:

* [Gradle Build Scans – insights for your project's build](https://scans.gradle.com#gradle)

